

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import st10394012_prog6112_a1.Book;
import st10394012_prog6112_a1.supply_management;


public class Supply_Management_Test {
     
    
    public Supply_Management_Test() {
    }
    
    //(Jeff & Joel, 2008)
    @Test
    public void testAddBook(){  
      supply_management manager = new supply_management();
      Book book = new Book("001","Java Programming","Author A",50.0);
      
      manager.addBook(book);
      
      assertEquals(1, manager.getSupplySize());
      
      
    }
    
    
    @Test
    public void testSearchBook_Found(){ 
      supply_management manager = new supply_management(); 
      Book book = new Book("001","Java Programming","Author A",50.0);
      
      manager.addBook(book);
      
      Book found = manager.searchBook("001");
      
      assertNotNull(found);
      assertEquals("Java Programming",found.getTitle());
    }
    
    @Test
    public void testSearchBook_NotFound(){
       supply_management manager = new supply_management();
       
       Book found = manager.searchBook("999");
       
       assertNull(found);
    }
    
    @Test
    public void testSellBook(){
       supply_management manager = new supply_management();
       Book book = new Book("001","Java Programming","Author A",50.0);
       
       manager.addBook(book);
       
       boolean sold = manager.sellBook("001");
       
       assertTrue(sold);
       assertEquals(0, manager.getSupplySize());
    }
    
}

/*
Reference List

1. Jeff, A & Joel, S. 2008. The short story. Question-and-answer website for computer programmers. Available on EBSCOhost at: https://stackoverflow.com/search?q=Junit+testing+in+java live [Accessed  03 September 2024].

*/