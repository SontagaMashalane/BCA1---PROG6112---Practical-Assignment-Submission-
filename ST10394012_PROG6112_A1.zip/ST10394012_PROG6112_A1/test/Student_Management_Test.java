/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import st10394012_prog6112_a1.Student;


public class Student_Management_Test {
    
    public Student_Management_Test() {
     
    }
    //(Jeff & Joel, 2008)
    @Test
    public void testSaveStudent(){
       ArrayList<Student> students = new ArrayList();
       Scanner scanner = new Scanner("123 \n John Doe \n 20 \n john@example.com \n Software Development \n");
       
       Student.saveStudent(students, scanner);
       
       assertEquals(1, students.size());
       assertEquals("John",students.get(0).getName());
     }
    
    @Test
     public void testGetValidAge(){
        Scanner scanner = new Scanner("18 \n ");
        
        int age = Student.getValidAge(scanner);
        
        assertEquals(18, age);
     }
     
     @Test
     public void testGetValidAge_InvalidAge(){
        Scanner scanner = new Scanner("15 \n 18 \n");
        
        int age = Student.getValidAge(scanner);
        
        assertEquals(18, age);
     }
     
     @Test
     public void testGetValidAge_InvalidCharacter(){
        Scanner scanner = new Scanner("abc \n 18 \n");
        
        int age = Student.getValidAge(scanner);
        
        assertEquals(18, age);
     }
     
     @Test
     public void testSearchStudent_NotFound(){
         ArrayList<Student> students = new ArrayList<>();
        Scanner scanner = new Scanner("123\n");
         
         Student.searchStudent(students, scanner);
         
         assertEquals(0, students.size());
     }
     
     @Test 
     public void testDeleteStudent_NotFound(){
        ArrayList<Student> students = new ArrayList<>();
        Scanner scanner = new Scanner("123 \n ");
        
        Student.deleteStudent(students, scanner);
        
        assertEquals(0, students.size());
     }
     
}
/*
Reference List

1. Jeff, A & Joel, S. 2008. The short story. Question-and-answer website for computer programmers. Available on EBSCOhost at: https://stackoverflow.com/search?q=Junit+testing+in+java live [Accessed  03 September 2024].

*/
