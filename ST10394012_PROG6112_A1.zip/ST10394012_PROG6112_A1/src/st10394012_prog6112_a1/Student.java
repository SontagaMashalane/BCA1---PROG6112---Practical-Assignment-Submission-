/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10394012_prog6112_a1;

import java.util.ArrayList;
import java.util.Scanner;


public class Student {
  private String id;
  private String name;
  private int age;
  private String email;
  private String course;
  
  public Student(String id,String name,int age,String email,String course){
     this.id = id;
     this.name = name;
     this.age = age;
     this.email = email;
     this.course = course;
  }
  
  public String getId(){
   return id;   
  }
  public String getName(){
     return name; 
  }
  public int getAge(){
      return age;
  }
  public String getEmail(){
      return email;
  }
  public String getCourse(){
      return course;
  }
  
  
  @Override
  public String toString(){
    return "\n" + "ID: "+ id + "\n" + "Name: "+ name + "\n" +"Age: "+ age + "\n" +"Email: "+ email + "\n" + "Course: "+ course + "\n"; 
  }
  
  //(Jeff & Joel, 2008)
  public static int getValidAge(Scanner scanner){
    int age = -1;
    while(true){
        try{
            System.out.println("Enter age: ");
            age = Integer.parseInt(scanner.nextLine());
            if (age >= 16){
                break;
            }else{
               System.out.println("Invalid age. Age must be 16 0r older."); 
            }
        }catch(NumberFormatException e){
            System.out.println("Invalid input. please enter a valid number.");
        }
    }
    return age;
  }
  
  public static void saveStudent(ArrayList<Student> students, Scanner scanner){
   System.out.println("Enter ID: ");
   String id = scanner.nextLine();
   
   System.out.println("Enter name: "); 
   String name = scanner.nextLine();
   
   int age = getValidAge(scanner);
   
   System.out.println("Enter email: ");
   String email = scanner.nextLine();
   
   System.out.println("Enter course: ");
   String course = scanner.nextLine();
   
   Student student = new Student(id,name,age,email,course);
   students.add(student);
   System.out.println("Student successfully saved ");
   
  }
  
  public static void searchStudent(ArrayList<Student> students, Scanner scanner){
    System.out.println("Enter student ID to search: ");
    String id = scanner.nextLine();
    for(Student student : students){
        if (student.getId().equals(id)){
            System.out.print(student);
            return;
        }
    }
    System.out.println("Student not found");
  }
  
  //(Jeff & Joel, 2008)
  public static void deleteStudent(ArrayList<Student> students,Scanner scanner){
    System.out.println("Enter Student ID to delete: ");
    String id = scanner.nextLine();
    for(Student student : students){
        if(student.getId().equals(id)){
           students.remove(student);
           System.out.println("Student succefully deleted: ");
           return;
        }
    
    }
    System.out.println("Student not found ");
  }
  //( Joyce , 2019)
  public static void studentReport(ArrayList<Student> students,Scanner scanner){
      if(students.isEmpty()){
          System.out.println("No students found");
          
      }else{
          for(int i = 0; i < students.size();i++){
             System.out.println("Student "+(i + 1) +": "+ students.get(i)); 
          }
      }
  }
  
  //(Jeff & Joel, 2008)
  public static void exitStudentApplication(){
      System.out.println("Existing application... ");
      System.exit(0);
  }
}
/*
Reference List

1. Joyce, F. 2019. Java programming. Boston: Cengage Learning, Inc.
2. Jeff, A & Joel, S. 2008. The short story. Question-and-answer website for computer programmers. Available on EBSCOhost at: https://stackoverflow.com/search?q=ArrayList+in+java live [Accessed  03 September 2024].

*/