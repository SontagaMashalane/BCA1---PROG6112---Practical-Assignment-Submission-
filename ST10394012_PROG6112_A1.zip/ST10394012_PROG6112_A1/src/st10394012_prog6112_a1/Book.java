package st10394012_prog6112_a1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Book {
    private String bookId;
    private String title;
    private String author;
    private double price;
    
    public Book(String bookId,String title,String author,double price){
       this.bookId = bookId;
       this.title = title;
       this.author = author;
       this.price = price;
    }
    public String getBookId(){
       return bookId; 
    }
    public String getTitle(){
        return title;
    }
    public String getAuthor(){
        return author;
    }
    public double getPrice(){
       return price; 
    }
    public String toString(){
        return "Book ID:"+bookId+ "Title:" + title + "Author:" + author + "Price:" + price;
    }
}
