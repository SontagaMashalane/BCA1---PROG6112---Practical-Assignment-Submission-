/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10394012_prog6112_a1;

import java.util.ArrayList;
import java.util.Scanner;


public class ST10394012_PROG6112_A1 {
    private ArrayList<Student> students = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        ST10394012_PROG6112_A1 Students = new ST10394012_PROG6112_A1();
        Students.menu();
        
    }
    
    //(Joyce, 2019)
    public void menu(){
        while(true){
          System.out.print("Enter (1) to launch menu or any other key to exit "); 
          String input = scanner.nextLine();
          if(input.equals("1")){
              displayMenu();
          }else{
              Student.exitStudentApplication();
              break;
          }
        }
    }
    
    //(Joyce, 2019)
    public void displayMenu(){
        System.out.println("1. Capture a new student ");
        System.out.println("2. Search for student ");
        System.out.println("3. Delete a student ");
        System.out.println("4. Print student report ");
        System.out.println("5. Exit application ");
        
        String choice = scanner.nextLine();
        switch(choice){
            case "1":
                Student.saveStudent(students, scanner);
                break;
            case "2":
                Student.searchStudent(students, scanner);
                break;
            case "3":
                Student.deleteStudent(students, scanner);
                break;
            case "4":
                Student.studentReport(students, scanner);
                break;
            case "5":
                Student.exitStudentApplication();
                break;
            default:
                System.out.println("Inavaild choice. Returning to menu");
                break;
        }
    }
    
}
/*
Reference List

Joyce, F. 2019. Java programming. Boston: Cengage Learning, Inc.


*/