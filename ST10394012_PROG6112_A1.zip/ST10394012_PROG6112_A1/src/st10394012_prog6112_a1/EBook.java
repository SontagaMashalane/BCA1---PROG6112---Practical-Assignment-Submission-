package st10394012_prog6112_a1;


import st10394012_prog6112_a1.Book;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class EBook extends Book{
    private double fileSize;
    
    public EBook(String bookId,String title,String author,double price){
       super(bookId, title, author,price); 
       this.fileSize = fileSize;
    }
    public double getFlieSize(){
        return fileSize;
    }
    public String toString(){
        return super.toString() + ", Filesize: " +fileSize+" MB ";
    }
}
